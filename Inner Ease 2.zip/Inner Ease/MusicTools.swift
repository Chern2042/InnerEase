//
//  MusicTools.swift
//  Inner Ease
//
//  Created by Christian Hernandez on 5/8/25.
//
import SwiftUI
    // for the music tools tab the whole idea is for the user to find calming music
// this page has some playlists that users can listen to and they also have explainations of the playslist itself and a url like to the playlist.

struct MusicToolView: View {
    //Sets music options as an array for the user to pick and choose for their music
    let musicOptions = [
        (
            title: "🎧 Lo-Fi",
            description: "Calming beats perfect for studying, journaling, or winding down.",
            link: URL(string: "https://www.youtube.com/watch?v=jfKfPfyJRdk")
        ),
        (
            title: "🎻 Classical",
            description: "Relaxing melodies to help you focus and soothe your nerves.",
            link: URL(string: "https://open.spotify.com/playlist/37i9dQZF1DWWEJlAGA9gs0")
        ),
        (
            title: "🌲 Nature Sounds",
            description: "Waves, rain, and forest ambience to ground your mind.",
            link: URL(string: "https://www.youtube.com/watch?v=1ZYbU82GVz4")
        ),
        (
            title: "🎵 Ambient",
            description: "Smooth, wordless textures to help you breathe and reset.",
            link: URL(string: "https://open.spotify.com/playlist/37i9dQZF1DWU0ScTcjJBdj")
        )
    ]

    var body: some View {
        //physical view on the screen or what the user is going to see
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                Text("🎶 Soothing Music")
                    .font(.title2)
                    .fontWeight(.bold)
//prints out each music option 
                ForEach(musicOptions, id: \.title) { item in
                    VStack(alignment: .leading, spacing: 6) {
                        Text(item.title)
                            .font(.headline)

                        Text(item.description)
                            .font(.subheadline)
                            .foregroundColor(.secondary)

                        if let url = item.link {
                            Link("Open Playlist", destination: url)
                                .font(.caption)
                                .foregroundColor(.blue)
                        }

                        Divider()
                    }
                }

                Spacer()
            }
            .padding()
        }
    }
}
