//
//  JournalView.swift
//  Inner Ease
//
//  Created by Christian Hernandez on 5/8/25.
//
import SwiftUI

struct JournalView: View{
    //keeps track of what is typed in the journal entry
    // stored in an array that time stamps the journal entry
    @State private var journalText = ""
    @ObservedObject var journalStorage: JournalStorage
    @State private var selectedTag = "None"
    @State private var searchText = ""
    //connects the mood a user may be feeling with their journal as a way to see progress
    let tagOptions = ["None", "Happy", "Anxious", "Grateful", "Angry"]
    
    var prompt: String? = nil
    
    var body: some View{
        //text heading
        VStack(alignment: .leading, spacing: 16){
            Text("Daily Journal 📝")
                .font(.title2)
                .fontWeight(.bold)
            
            // the input text box for the user to type in their journal
            if let prompt = prompt, journalText.isEmpty{
                Text("✏️ Prompt: \(prompt)")
                    .font(.subheadline)
                    .foregroundColor(.blue)
                    .padding(.bottom, 4)
                
            }
            //text editor for the user to type their thoughts 
            TextEditor(text: $journalText)
                .frame(height: 150)
                .overlay(
                    RoundedRectangle(cornerRadius: 8)
                        .stroke(Color.gray.opacity(0.5))
                        .onAppear {
                            if let prompt = prompt, journalText.isEmpty {
                                journalText = "\(prompt)\n\n"
                            }
                        }
                )
            //tags for the journal entry for the user for organization based on moood
            Picker("Tag", selection: $selectedTag) {
                ForEach(tagOptions, id: \.self) { tag in
                    Text(tag)
                }
            }
            .pickerStyle(.segmented)
            //buton that the user will press to save their entry
            Button("Save Entry") {
                if !journalText.trimmingCharacters(in: .whitespaces).isEmpty {
                    journalStorage.saveEntry(journalText, tag: selectedTag)
                    journalText = ""
                    selectedTag = "None"
                }
            }
            .font(.headline)
            .frame(maxWidth: . infinity)
            .padding()
            .background(Color("CardBackground"))
            .cornerRadius(10)
            
            
            Divider()
            // shows past entries for user to look back on
            Text("Past Entries")
                .font(.headline)
            
            TextField("Search entries...", text: $searchText)
                .textFieldStyle(RoundedBorderTextFieldStyle())
            // filters based on text within the entry, maybe later I'll make it so you have to title entries and go based on that
            var filteredEntries: [JournalEntry] {
                if searchText.isEmpty {
                    return journalStorage.entries
                } else {
                    return journalStorage.entries.filter {
                        $0.text.localizedCaseInsensitiveContains(searchText) ||
                        $0.tag.localizedCaseInsensitiveContains(searchText)
                    }
                }
            }
            //lists of previous entries
            //scroll through past entries
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 12) {
                    ForEach(filteredEntries) { entry in
                        NavigationLink(destination: JournalDetailView(entry: entry)) {
                            VStack(alignment: .leading, spacing: 4) {
                                Text(entry.text.prefix(50) + "…")
                                HStack {
                                    Text(entry.timestamp.formatted(date: .abbreviated, time: .shortened))
                                        .font(.caption)
                                        .foregroundColor(.gray)
                                    Spacer()
                                    //none tag
                                    if entry.tag != "None" {
                                        Text(entry.tag)
                                            .font(.caption)
                                            .foregroundColor(.blue)
                                            .padding(.horizontal, 6)
                                            .padding(.vertical, 2)
                                            .background(Color("CardBackground"))
                                            .cornerRadius(6)
                                    }
                                }
                            }
                            .padding()
                            .background(Color("CardBackground"))
                            .cornerRadius(10)
                        }
                    }
                }
                .padding()
            }
            }
            
            Spacer()
        }
        
        
    }



