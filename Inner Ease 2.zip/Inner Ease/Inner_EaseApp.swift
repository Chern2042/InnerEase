//
//  Inner_EaseApp.swift
//  Inner Ease
//
//  Created by Christian Hernandez on 5/7/25.
//

import SwiftUI

@main
struct Inner_EaseApp: App {
   
    var body: some Scene {
        WindowGroup {
            ContentView()
            
        }
    }
}
