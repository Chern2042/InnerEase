//
//  ToolsPage.swift
//  Inner Ease
//
//  Created by Christian Hernandez on 5/7/25.
//

import SwiftUI
// the tools page is an informitive page to help people find things to calm them down
struct ToolsView:  View {
    
    @ObservedObject var journalStorage: JournalStorage
    //Tools 3.0:
    //Within this version I changed the texts to labels to give it a cleaner look with icons
    //Goals:
    // I do want to turn these into buttons where they go to a secondary page where the user can get more info on each tab
    
    //V5.0:
    //In this version all the tab or buttons on the tools page work. The functions include Breathing excerise, music playlists,Journal Prompts, and Walking goals
    //The breathing exercise is a timer that tells the user when to breathe in , then hold , and breathe out. Each having a four second wait
    //The Journal prompts are hardcoded prompts that asks the user a random question and sends the user to the journaling page in the app. Once the they're in the journalling page the first line will be the prompt.
    // The Music playlist is playlists of music that is soothing for a person to hear theres an explanation and a link to the playlist either spotify or youtube
    //The Walking challenge is meant for the user to choose if they'd like to challenge for a walk or run. Theres different diffculties in the app being easy medium and hard
    var body: some View{
        VStack(alignment: .leading, spacing: 16){
            Text("Mental Health Tools")
                .font(.title2)
                .fontWeight(.bold)
            // placeholder list
            //Now Functional
            List{
                //navigation links to each function
                NavigationLink(destination: BreathingTool()){
                    Label("Deep breathing excersice",systemImage: "lungs.fill")
                          }
                NavigationLink(destination: JournalPromptToolView(journalStorage: journalStorage)){
                    Label("Quick Journal Prompt",systemImage: "square.and.pencil")
                }
                NavigationLink(destination: MusicToolView ()){
                    Label("Calmimng music playlist",systemImage: "music.note")
                }
                NavigationLink(destination: WalkingGoalView ()){
                    Label("Walk challenge",systemImage: "figure.walk")
                }
          
                Label("Drink Water ",systemImage: "drop.fill")
            }
        }
    }
  }

