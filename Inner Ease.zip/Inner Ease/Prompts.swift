//
//  Prompts.swift
//  Inner Ease
//
//  Created by Christian Hernandez on 5/8/25.
//

import SwiftUI
//v5.0: within this version one of the main goals was to get the tools tab or page to be fully funcitional
//one of the functions of the tools page is this ("the prompts"). This is intended for when the user needs something to write that has a connection to mental health. By clicking the Journal Prompt button on the tools page the user gets redirected to the Journal page where they're given a prompt to write about

struct JournalPromptToolView: View {
    @ObservedObject var journalStorage: JournalStorage
// Here are the prompts, they're saved into array.
    let prompts = [
        "What are you grateful for today?",
        "What emotion are you feeling most strongly right now?",
        "Describe one good thing that happened this week.",
        "What’s something you need to let go of?",
        "What’s a challenge you overcame recently?",
        "What is something you want to change and how can you get there?"
    ]

    var body: some View {
        //randomPrompt uses .randomElement() to find a random prompt to select to display on the screen.
        let randomPrompt = prompts.randomElement() ?? ""
//visual prompt screen
        return VStack(spacing: 24) {
            Text("📝 Quick Journal Prompt")
                .font(.title2)
                .fontWeight(.bold)
//shows the prompt on the screen
            Text("“\(randomPrompt)”")
                .italic()
                .multilineTextAlignment(.center)
                .padding()
//The navigation takes the user from the prompt start screen to the Journaling Screen
            NavigationLink(destination: JournalView(journalStorage: journalStorage, prompt: randomPrompt)) {
                Text("Start Writing")
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.blue.opacity(0.2))
                    .cornerRadius(10)
            }

            Spacer()
        }
        .padding()
    }
}
