//
//  BreathingTool.swift
//  Inner Ease
//
//  Created by Christian Hernandez on 5/8/25.
//
import SwiftUI
// the breathing tool is a way for users to pace their breathes its a timer that switches every four seconds and tells the user what to do.
struct BreathingTool: View{
   
    
    // private varianbles for the timer
    @State private var phase = "Ready?"
    @State private var cycleTimer: Timer?
    @State private var cycleStep = 0
    @State private var isRunning = false
    
    //an array telling the user what to do and how long they should do it for.
    let steps = [
        ("Breathe In", 4.0),
        ("Hold", 4.0),
        ("Breathe Out", 4.0),
        ("Hold", 4.0)
    ]
    
    
    var body: some View{
        // shows the timer on the screen for the user to follow
        VStack(spacing:40){
            Text("🫁 Deep Breathing")
                .font(.title2)
                .fontWeight(.bold)
            Text(phase)
                       .font(.largeTitle)
                       .fontWeight(.semibold)
                       .transition(.opacity)
                       .animation(.easeInOut, value: phase)

                   if isRunning {
                       Button("Stop") {
                           stopBreathing()
                       }
                       .padding()
                       .background(Color.red.opacity(0.2))
                       .cornerRadius(10)
                   } else {
                       Button("Start") {
                           startBreathing()
                       }
                       .padding()
                       .background(Color.blue.opacity(0.2))
                       .cornerRadius(10)
                   }

                   Spacer()
               }
               .padding()
               .onDisappear {
                   stopBreathing()
            }
            
        }
    //timer function goes through the array
    func startBreathing() {
          isRunning = true
          cycleStep = 0
          phase = steps[cycleStep].0

          cycleTimer = Timer.scheduledTimer(withTimeInterval: steps[cycleStep].1, repeats: true) { _ in
              cycleStep = (cycleStep + 1) % steps.count
              phase = steps[cycleStep].0
          }
      }
// the stop or ready function
      func stopBreathing() {
          isRunning = false
          cycleTimer?.invalidate()
          cycleTimer = nil
          phase = "Ready?"
      }
    }

