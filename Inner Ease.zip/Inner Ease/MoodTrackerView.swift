//
//  MoodTrackerView.swift
//  Inner Ease
//
//  Created by Christian Hernandez on 5/7/25.
//

import SwiftUI


import Foundation
//Mood entry object used for storing moods of users

struct moodEntry:Identifiable, Codable{
    var id = UUID()
    let mood: String
    let timestamp: Date
}
// On the home page therea a "check in" or "how are you feeling?" question
//This page does all the heavy lifting when it comes to the moods
// First it displays the moods and the question and then the user clicks their answer
//then the mood gets added to the mood list and then gets display with any previous moods 
struct MoodTrackerView: View {
    @StateObject private var moodStorage = MoodStorage()
    let moods = ["😊", "😐", "😢", "😡", "🥳"]

    var body: some View {
        VStack(spacing: 16) {
            Text("How are you feeling today?")
                .font(.title2)

            HStack(spacing: 16) {
                ForEach(moods, id: \.self) { mood in
                    Button(action: {
                        moodStorage.saveMood(mood)
                    }) {
                        Text(mood)
                            .font(.largeTitle)
                    }
                }
            }

            Divider()

            Text("Recent Mood Logs")
                .font(.headline)

            List(moodStorage.moods) { entry in
                VStack(alignment: .leading) {
                    Text(entry.mood)
                        .font(.title3)
                    Text(entry.timestamp.formatted(date: .abbreviated, time: .shortened))
                        .font(.caption)
                        .foregroundColor(.gray)
                }
            }

            Spacer()
        }
        .padding()
    }
}

class MoodStorage: ObservableObject {
    @Published var moods: [moodEntry] = []

    private let filename = "moods.json"

    init() {
        load()
    }
// saves the users current mood
    func saveMood(_ mood: String) {
        let newEntry = moodEntry(mood: mood, timestamp: Date())
        moods.insert(newEntry, at: 0)
        save()
    }
//function that saves the mood to a file and says if it worked or not
    private func save() {
        do {
            let data = try JSONEncoder().encode(moods)
            let url = getDocumentsDirectory().appendingPathComponent(filename)
            try data.write(to: url)
            print("✅ Mood saved to JSON file.")
        } catch {
            print("❌ Failed to save moods: \(error)")
        }
    }
    //loads mood data
    private func load() {
        let url = getDocumentsDirectory().appendingPathComponent(filename)
        guard let data = try? Data(contentsOf: url) else { return }

        if let decoded = try? JSONDecoder().decode([moodEntry].self, from: data) {
            moods = decoded
        } else {
            print("❌ Failed to decode saved moods.")
        }
    }

    private func getDocumentsDirectory() -> URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }
}
