//
//  WalkingGoalView.swift
//  Inner Ease
//
//  Created by Christian Hernandez on 5/8/25.
//
import SwiftUI
//5.0: Part of the tools functions where a person can set a walking goal based on a difficulty 
struct WalkingGoalView: View {
    @State private var selectedDifficulty: String? = nil
//Visually sets up the screen showing the difficulty levels and asking the user to choose one
    var body: some View {
        VStack(spacing: 20) {
            Text("🚶‍♂️ Walking Goal")
                .font(.title2)
                .fontWeight(.bold)

            Text("Choose a difficulty level to get your walking time and motivation.")
                .multilineTextAlignment(.center)
                .padding(.bottom)

            ForEach(["Easy", "Medium", "Hard"], id: \.self) { level in
                Button(action: {
                    selectedDifficulty = level
                }) {
                    Text(level)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.blue.opacity(0.2))
                        .cornerRadius(10)
                }
            }
// checks for the level selected and prints out the goal for the level
            if let difficulty = selectedDifficulty {
                Divider().padding(.vertical, 10)

                Text("🏁 Goal for \(difficulty) Walk")
                    .font(.headline)
// prints the walking time for the certain difficulty
                Text(walkingTime(for: difficulty))
                    .font(.title2)
                    .fontWeight(.semibold)
//Print a motiavtional message on the screen to encourage the user
                Text(motivationMessage(for: difficulty))
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
                    .padding(.top, 4)
            }

            Spacer()
        }
        .padding()
    }
//function that walking time to each level
    func walkingTime(for level: String) -> String {
        switch level {
        case "Easy": return "Walk for 5 minutes"
        case "Medium": return "Walk for 10–15 minutes"
        case "Hard": return "Walk for 20–30 minutes"
        default: return ""
        }
    }
//function that gives the user a motivational message based on the level they've selected
    func motivationMessage(for level: String) -> String {
        switch level {
        case "Easy": return "Even a short walk can reset your mind."
        case "Medium": return "Stretch your legs, breathe deeply, and feel your pace."
        case "Hard": return "Challenge yourself—you’ve got the energy to finish strong!"
        default: return ""
        }
    }
}
